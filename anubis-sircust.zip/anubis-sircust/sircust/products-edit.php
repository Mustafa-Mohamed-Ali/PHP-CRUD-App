<?php
include "basic.php";
session();
if(isset($_POST["prodId"])) {
  prod_update($_POST["prodId"], $_POST["prodName"]);
}
$prod = prod_edit($_GET["id"]);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Edit Products</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/bootstrap.bundle.min.js" charset="utf-8"></script>
    <script src="js/script.js" charset="utf-8"></script>
  </head>
  <body>
    <?php include "navbar.php"; ?>
    <h1>Edit Products</h1>
    <form action="products-edit.php" method="post">
      <label for="prodId">Product ID</label>
      <input type="text" name="prodId" value="<?php echo $prod["id"]; ?>">
      <label for="ProdName">Product Name</label>
      <input type="text" name="prodName" value="<?php echo $prod["name"]; ?>">

      <button type="submit">Save</button>
      <a href="#">Back</a>
    </form>
  </body>
</html>
