<?php
include "basic.php";
session();
if (isset($_POST["cityName"])) {
  cities_new($_POST["cityName"], $fileName);
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>New City</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/bootstrap.bundle.min.js" charset="utf-8"></script>
    <script src="js/script.js" charset="utf-8"></script>
  </head>
  <body>
  <?php include 'navbar.php'; ?>
    <div class="container">
      <h1 class="display-1 mt-4 mb-4">New City</h1>
      <div class="row">
        <form action="cities-new.php" method="post" enctype="multipart/form-data">
          <div class="form-group mb-4">
            <label for="cityName">City Name: </label>
            <input type="text" id="cityName" name="cityName" class="form-control"><br>
          </div>
          <div class="form-group mb-4">
            <label for="cityLogo">Image</label>
            <input type="file" id="cityLogo" name="cityLogo" class="form-control" value="">
          </div>
          <button type="submit" class="btn btn-success">Save</button>
          <a href="customers-list.php" class="btn btn-secondary">Back</a>
        </form>
      </div>
    </div>
  </body>
</html>
