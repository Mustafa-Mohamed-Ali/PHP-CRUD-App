<?php
include "basic.php";
session();
if(isset($_POST["prodName"])) {
  prod_new($_POST["prodName"]); 
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>New Products</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/bootstrap.bundle.min.js" charset="utf-8"></script>
    <script src="js/script.js" charset="utf-8"></script>
  </head>
  <body>
    <?php include "navbar.php"; ?>
    <h1>New Products</h1>
    <form action="products-new.php" method="post">
      <label for="ProdName">Products Name</label>
      <input type="text" name="prodName">

      <button type="submit">Save</button>
      <a href="#">Back</a>
    </form>
  </body>
</html>
