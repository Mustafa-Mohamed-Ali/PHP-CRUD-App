<?php
include "basic.php";
session();
if (isset($_GET["id"])) {
    prod_delete($_GET["id"], $_GET["action"]);
}
$data = prod_list("deleted");
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <title>Products-list</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/bootstrap.bundle.min.js" charset="utf-8"></script>
    <script src="js/script.js" charset="utf-8"></script>
</head>

<body>
    <?php include "navbar.php"; ?>
    <div class="container">
        <div class="row">
            <h1 class="display-1 mt-4 mb-4 text-danger">Products Trash</h1>
            <table class="table table-bordered">
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Action</th>
                </tr>
                <?php while ($prod = mysqli_fetch_assoc($data)) { ?>
                    <tr>
                        <td><?php echo $prod['id']; ?></td>
                        <td><?php echo $prod['name']; ?></td>
                        <td>
                            <a class="btn btn-success" href="products-trash.php?id=<?php echo $prod["id"]; ?>&action=restore">Restore</a>
                            <a class="btn btn-danger" href="products-trash.php?id=<?php echo $prod["id"]; ?>&action=forever">Delete Forever</a>
                        </td>
                    </tr>
                <?php } ?>
</body>

</html>