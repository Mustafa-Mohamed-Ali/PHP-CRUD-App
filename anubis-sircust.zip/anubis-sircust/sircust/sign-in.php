<?php
include 'basic.php';
if(isset($_POST["username"])){
  $user = get_user($_POST["username"]);
  if(!isset($user["username"])){
    $error = "This Username doesn't exist";
  } else {
    if(password_verify($_POST["password"], $user["password"])){
      $_SESSION["username"] = $user["username"];
      header("Location: index.php");
    } else {
      $error = "This Password is Invalid";
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Login to your Account - <?php echo $companyName; ?></title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/bootstrap.bundle.min.js" charset="utf-8"></script>
    <script src="js/script.js" charset="utf-8"></script>
  </head>
  <body>
    <div class="container">
    <div class="row">
        <?php if(isset($error)) { ?>
              <p class="alert alert-danger col-12 mt-4"> <?php echo $error; ?></p>
        <?php  } ?>
      </div>
      <h1 class="display-1 text-primary mt-5 mb-5">Login to your Account</h1>
      <div class="row">
        <form action="sign-in.php" method="post">
          <div class="form-group">
            <label for="username">Username:</label>
            <input type="text" name="username" class="form-control">
          </div>
          <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" name="password" class="form-control">
          </div>
          <button type="submit" class="btn btn-primary mt-5">Sign in</button>
        </form>
        <p class="text-center mt-5">Don't have an Account ? <a href="sign-up.php">Create a new Account</a></p>
      </div>
    </div>
  </body>
</html>
