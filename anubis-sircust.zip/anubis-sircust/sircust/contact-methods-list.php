<?php
include "basic.php";
session();
if (isset($_GET["id"])) {
  cm_delete($_GET["id"], $_GET["action"]);
}

$data = cm_list();
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Contact-methods List</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/bootstrap.bundle.min.js" charset="utf-8"></script>
    <script src="js/script.js" charset="utf-8"></script>
  </head>
  <body>
    <?php include 'navbar.php'; ?>
    <div class="container">
      <div class="row">
        <h1 class="display-1">Contact-methods List</h1>
        <table class="table">
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Action</th>
          </tr>
          <?php while($pcm = mysqli_fetch_assoc($data)) { ?>
          <tr>
            <td><?php echo $pcm["id"]; ?></td>
            <td><?php echo $pcm["name"]; ?></td>
            <td>
              <a class="btn btn-primary" href="contact-methods-edit.php?id=<?php echo $pcm["id"]; ?>">Edit</a>
              <a class="btn btn-danger" href="contact-methods-list.php?id=<?php echo $pcm["id"]; ?>&action=delete">Delete</a>
            </td>
          </tr>
          <?php } ?>
        </table>
      </div>
    </div>
  </body>
</html>
