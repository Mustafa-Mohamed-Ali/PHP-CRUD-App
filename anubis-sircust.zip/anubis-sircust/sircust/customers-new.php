<?php
include "basic.php";
session();
if (isset($_POST["name"])) {
  cust_new($_POST["name"], $_POST["phone"], $_POST["email"], $_POST["address"], $_POST["city"], $_POST["bdate"], $_POST["pcm"]);
}
$sql = "SELECT * FROM cities";
$cities_list = mysqli_query($conn, $sql);

$sql = "SELECT * FROM contact_methods";
$cm_list = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>New Customer</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/bootstrap.bundle.min.js" charset="utf-8"></script>
    <script src="js/script.js" charset="utf-8"></script>
  </head>
  <body>
    <?php include 'navbar.php'; ?>
    <h1>New Customer</h1>
    <div class="container">
    <form action="customers-new.php" method="post">
      <label for="name">Name</label>
      <input type="text" name="name" class="form-control" > </br>

      <label for="phone">Phone</label>
      <input type="text" name="phone" class="form-control"></br>

      <label for="email">Email</label>
      <input type="text" name="email" class="form-control"></br>

      <label for="address">Address</label>
      <input type="text" name="address" class="form-control"></br>

      <label for="city">City</label>
      <select class="form-control" name="city">
        <?php while($city = mysqli_fetch_assoc($cities_list)) { ?>
        <option value="<?php echo $city["id"]; ?>"><?php echo $city["name"]; ?></option>
        <?php } ?>
      </select></br>

      <label for="bdate">Birth Date</label>
      <input type="date" name="bdate" class="form-control"></br>

      <label for="pcm">Preferred Contact Method</label>
      <select class="form-control" name="pcm">
          <?php while($cm = mysqli_fetch_assoc($cm_list)) { ?>
          <option value="<?php echo $cm["id"]; ?>"><?php echo $cm["name"]; ?> </option>
          <?php } ?>
      </select></br>

      <button type="submit" class="form-control">Save</button>
      </div>
    </form>
  </body>
</html>
