<?php
include "basic.php";
session();
if(isset($_POST["depName"])) {
  dep_new($depName = $_POST["depName"]);
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>New Department</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/bootstrap.bundle.min.js" charset="utf-8"></script>
    <script src="js/script.js" charset="utf-8"></script>
  </head>
  <body>
    <?php include "navbar.php"; ?>
    <h1>New Department</h1>
    <form action="departments-save.php" method="post">
      <label for="department">Department Name</label>
      <input type="text" name="depName">

      <button type="submit">Save</button>
      <a href="#">Back</a>
    </form>
  </body>
</html>
