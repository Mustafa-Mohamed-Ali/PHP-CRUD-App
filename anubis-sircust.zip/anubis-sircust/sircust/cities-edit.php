<?php
include "basic.php";
session();
if (isset($_POST["cityID"])) {
  cities_update($_POST["cityID"], $_POST["cityName"], $_FILES["cityLogo"]);
}
$city = cities_edit($_GET["id"]);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Edit City</title>
    <title>Cities List</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/bootstrap.bundle.min.js" charset="utf-8"></script>
    <script src="js/script.js" charset="utf-8"></script>
  </head>
  <body>
    <?php include "navbar.php"; ?>
    <h1>Edit City</h1>
    <form action="cities-edit.php" method="post" enctype="multipart/form-data">
      <label for="cityID">City ID</label>
      <input type="text" name="cityID" value="<?php echo $city["id"]; ?>">

      <label for="cityName">City Name</label>
      <input type="text" name="cityName" value="<?php echo $city["name"]; ?>">

      <label for="cityLogo">City Logo</label>
      <img class="profile-img" src="img/cities/<?php echo $city["image"]; ?>">
      <input type="file" name="cityLogo">


      <button type="submit">Save</button>
      <a href="#">Back</a>
    </form>
  </body>
</html>
