<?php 
function prod_list($status = "active") {
    global $conn;
    if($status == "active") {
        $sql = "SELECT * FROM products WHERE active = 1";
    }
    elseif ($status == "deleted"){
    $sql = "SELECT * FROM products WHERE active = 0";
    }
    $data = mysqli_query($conn, $sql);
    return $data;
}
function prod_new($prodName) {
    global $conn;
    $sql = "INSERT INTO products (name) VALUES ('$prodName')";
    mysqli_query($conn, $sql);
    header("Location: products-list.php");
}
function prod_delete($id, $action) {
    global $conn;
    if($action == "delete") {
        $sql = "UPDATE products SET active = 0 WHERE id = '$id'";
        $location = "products-list.php";
    }
    elseif($action == "restore") {
        $sql = "UPDATE products SET active = 1 WHERE id = '$id'";
        $location = "products-trash.php";
    }
    elseif($action == "forever") {
        $sql = "DELETE FROM products WHERE id = '$id'";
        $location = "products-trash.php";
    }
    mysqli_query($conn, $sql);
    header("Location: $location");
}
function prod_edit($id) {
    global $conn;
    $sql = "SELECT * FROM products WHERE id = '$id'";
    $data = mysqli_query($conn, $sql);
    $prod = mysqli_fetch_assoc($data);
    return $prod;
}
function prod_update($id, $prodName) {
    global $conn;
    $sql = "UPDATE products SET name = '$prodName' WHERE id = '$id'";
    mysqli_query($conn, $sql);
    header("Location: products-list.php");
}
?>