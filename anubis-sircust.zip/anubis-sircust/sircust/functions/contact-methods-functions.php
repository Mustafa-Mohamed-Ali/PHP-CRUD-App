<?php 
function cm_list($status = "active") {
    global $conn;
    if($status == "active") {
        $sql = "SELECT * FROM contact_methods WHERE active = 1";
    }
    elseif ($status == "deleted") {
        $sql = "SELECT * FROM contact_methods WHERE active = 0";
    }
    $data = mysqli_query($conn, $sql);
    return $data;
}
function cm_new($cm) {
    global $conn;
    $sql = "INSERT INTO contact_methods (name) VALUES ('$cm')";
    mysqli_query($conn, $sql);
    header("Location: contact-methods-list.php");
}
function cm_delete($id, $action) {
    global $conn;
    if ($action == "delete") {
    $sql = "UPDATE contact_methods SET active = 0 WHERE id = '$id'";
    $location = "contact-methods-list.php";
    }
    elseif ($action == "restore") {
    $sql = "UPDATE contact_methods SET active = 1 WHERE id = '$id'";
    $location = "contact-methods-trash.php";
    }
    elseif ($action == "forever") {
    $sql = "DELETE FROM contact_methods WHERE id = '$id'";
    $location = "contact-methods-trash.php";
    }
    mysqli_query($conn, $sql);
    header("Location: $location");
}
function cm_edit($id) {
    global $conn;
    $sql = "SELECT * FROM contact_methods WHERE id = '$id'";
    $data = mysqli_query($conn, $sql);
    $pcm = mysqli_fetch_assoc($data);
    return $pcm;
}
function cm_update($id, $name) {
    global $conn;
    $sql = "UPDATE contact_methods SET name = '$name' WHERE id = '$id'";
    mysqli_query($conn, $sql);
    header("Location: contact-methods-list.php");
}
?>