<?php 
function dep_list($status = "active") {
    global $conn;
    if($status == "active") {
        $sql = "SELECT * FROM departments WHERE active = 1";
    }
    elseif ($status == "deleted"){
    $sql = "SELECT * FROM departments WHERE active = 0";
    }
    $data = mysqli_query($conn, $sql);
    return $data;
}

function dep_new($depName) {
    global $conn;
    $sql = "INSERT INTO departments (name) VALUES ('$depName')";
    mysqli_query($conn, $sql);
    header("Location: departments-list.php");
}
function dep_delete($id, $action) {
    global $conn;
    if($action == "delete") {
        $sql = "UPDATE departments SET active = 0 WHERE id = '$id'";
        $location = "departments-list.php";
    }
    elseif($action == "restore") {
        $sql = "UPDATE departments SET active = 1 WHERE id = '$id'";
        $location = "departments-trash.php";
    }
    elseif($action == "forever") {
        $sql = "DELETE FROM departments WHERE id = '$id'";
        $location = "departments-trash.php";
    }
    mysqli_query($conn, $sql);
    header("Location: $location");
}
function dep_edit($id) {
    global $conn;
    $sql = "SELECT * FROM departments WHERE id = '$id'";
    $data = mysqli_query($conn, $sql);
    $dep = mysqli_fetch_assoc($data);
    return $dep;
}
function dep_update($id, $depName) {
    global $conn;
    $sql = "UPDATE departments SET name = '$depName' WHERE id = '$id'";
    mysqli_query($conn, $sql);
    header("Location: departments-list.php");
}
?>