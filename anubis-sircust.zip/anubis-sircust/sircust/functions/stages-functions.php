<?php 
function sta_list($status = "active") {
    global $conn;
    if($status == "active") {
        $sql = "SELECT * FROM stages WHERE active = 1";
    }
    elseif ($status == "deleted"){
    $sql = "SELECT * FROM stages WHERE active = 0";
    }
    $data = mysqli_query($conn, $sql);
    return $data;
}
function sta_new($stageName) {
    global $conn;
    $sql = "INSERT INTO stages (name) VALUES ('$stageName')";
    mysqli_query($conn, $sql);
    header("Location: stages-list.php");
}
function sta_delete($id, $action) {
    global $conn;
    if($action == "delete") {
        $sql = "UPDATE stages SET active = 0 WHERE id = '$id'";
        $location = "stages-list.php";
    }
    elseif($action == "restore") {
        $sql = "UPDATE stages SET active = 1 WHERE id = '$id'";
        $location = "stages-trash.php";
    }
    elseif($action == "forever") {
        $sql = "DELETE FROM stages WHERE id = '$id'";
        $location = "stages-trash.php";
    }
    mysqli_query($conn, $sql);
    header("Location: $location");
}
function sta_edit($id) {
    global $conn;
    $sql = "SELECT * FROM stages WHERE id = '$id'";
    $data = mysqli_query($conn, $sql);
    $sta = mysqli_fetch_assoc($data);
    return $sta;
}
function sta_update($id, $stageName) {
    global $conn;
    $sql = "UPDATE stages SET name = '$stageName' WHERE id = '$id' ";
    mysqli_query($conn, $sql);
    header("Location: stages-list.php");
}
?>
