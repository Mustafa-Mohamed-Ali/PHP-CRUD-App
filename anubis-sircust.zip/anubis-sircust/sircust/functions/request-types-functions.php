<?php 
function req_list($status = "active") {
    global $conn;
    if($status == "active") {
        $sql = "SELECT * FROM request_types WHERE active = 1";
    }
    elseif ($status == "deleted"){
    $sql = "SELECT * FROM request_types WHERE active = 0";
    }
    $data = mysqli_query($conn, $sql);
    return $data;
}
function req_new($reqName) {
    global $conn;
    $sql = "INSERT INTO request_types (name) VALUES ('$reqName')";
    mysqli_query($conn, $sql);
    header("Location: request-types-list.php");
}
function req_delete($id, $action) {
    global $conn;
    if($action == "delete") {
        $sql = "UPDATE request_types SET active = 0 WHERE id = '$id'";
        $location = "request-types-list.php";
    }
    elseif($action == "restore") {
        $sql = "UPDATE request_types SET active = 1 WHERE id = '$id'";
        $location = "request-types-trash.php";
    }
    elseif($action == "forever") {
        $sql = "DELETE FROM request_types WHERE id = '$id'";
        $location = "request-types-trash.php";
    }
    mysqli_query($conn, $sql);
    header("Location: $location");
}
function req_edit($id) {
    global $conn;
    $sql = "SELECT * FROM request_types WHERE id = '$id'";
    $data = mysqli_query($conn, $sql);
    $req = mysqli_fetch_assoc($data);
    return $req;
}
function req_update($id, $reqName) {
    global $conn;
    $sql = "UPDATE request_types SET name = '$reqName' WHERE id = '$id' ";
    mysqli_query($conn, $sql);
    header("Location: request-types-list.php");
}
?>
