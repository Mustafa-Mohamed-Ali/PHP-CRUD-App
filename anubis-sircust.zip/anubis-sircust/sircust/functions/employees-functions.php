<?php
function emp_list($status = "active") {
    global $conn;
    if($status == "active") {
        $sql = "SELECT employees.id AS empid, employees.active, employees.name AS empname, employees.phone, employees.email, employees.city_id, employees.department_id, employees.job_title, cities.name AS cityname, cities.id, departments.name AS depname, departments.id FROM employees,cities, departments WHERE employees.active = 1 AND cities.id = employees.city_id AND departments.id = department_id";
    }
    elseif($status == "deleted") {
        $sql = "SELECT employees.id AS empid, employees.active, employees.name AS empname, employees.phone, employees.email, employees.city_id, employees.department_id, employees.job_title, cities.name AS cityname, cities.id, departments.name AS depname, departments.id FROM employees,cities, departments WHERE employees.active = 0 AND cities.id = employees.city_id AND departments.id = department_id";
    }
    $data = mysqli_query($conn, $sql);
    return $data;
}
function emp_new($name, $phone, $email, $job, $dep, $city) {
    global $conn;
    $sql = "INSERT INTO employees (name, phone, email, job_title, department_id, city_id) VALUES ('$name', '$phone', '$email', '$job', '$dep', '$city')";
    mysqli_query($conn, $sql);
    header("Location: emp-list.php");
}
function emp_delete($id, $action) {
    global $conn;
    if($action == "delete") {
        $sql = "UPDATE employees SET active = 0 WHERE id = '$id'";
        $location = "emp-list.php";
    }
    elseif($action == "restore") {
        $sql = "UPDATE employees SET active = 1 WHERE id = '$id'";
        $location = "emp-trash.php";
    }
    elseif($action == "forever") {
    $sql = "DELETE FROM employees WHERE id = '$id'";
    $location = "emp-trash.php";
    }
    mysqli_query($conn, $sql);
    header("Location: $location");
}
function emp_edit($id) {
    global $conn;
    $sql = "SELECT * FROM employees WHERE id = '$id'";
    $data = mysqli_query($conn, $sql);
    $emp = mysqli_fetch_assoc($data);
    return $emp;
}
function emp_update($id, $name, $phone, $email, $job, $dep, $city) {
    global $conn;
    $sql = "UPDATE employees SET name = '$name', phone = '$phone', email = '$email', job_title = '$job', department_id = '$dep', city_id = '$city' WHERE id = '$id'";
    mysqli_query($conn, $sql);
    header("Location: emp-list.php");
}
?>
