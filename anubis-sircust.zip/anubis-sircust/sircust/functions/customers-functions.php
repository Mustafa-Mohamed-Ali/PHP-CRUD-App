<?php
function cust_list($status = "active") {
    global $conn;
    if($status == "active") {
        $sql = "SELECT customers.active, customers.id, customers.name AS cname, customers.phone, customers.email, customers.address, customers.bdate, cities.name AS cityname, contact_methods.name AS cmname FROM customers, cities, contact_methods WHERE customers.active = 1 AND cities.id = customers.city_id AND contact_methods.id = customers.pcm";
    }
    if($status == "deleted") {
        $sql = "SELECT customers.active, customers.id, customers.name AS cname, customers.phone, customers.email, customers.address, customers.bdate, cities.name AS cityname, contact_methods.name AS cmname FROM customers, cities, contact_methods WHERE customers.active = 0 AND cities.id = customers.city_id AND contact_methods.id = customers.pcm";
    }
    $data = mysqli_query($conn, $sql);
    return $data;
}
function cust_new($name, $phone, $email, $address, $city, $bdate, $pcm) {
    global $conn;
    $sql = "INSERT INTO customers (name, phone, email, address, city_id, bdate, pcm) VALUES ('$name', '$phone', '$email', '$address', '$city', '$bdate', '$pcm')";
    mysqli_query($conn, $sql);
    header("Location: customers-list.php");
}
function cust_delete($id, $action) {
    global $conn;
    if ($action == "delete") {
    $sql = "UPDATE customers SET active = 0 WHERE id = '$id'";
    $location = "customers-list.php";
    }
    elseif ($action == "restore") {
    $sql = "UPDATE customers SET active = 1 WHERE id = '$id'";
    $location = "customers-trash.php";
    }
    elseif ($action == "forever") {
    $sql = "DELETE FROM customers WHERE id = '$id'";
    $location = "customers-trash.php";
    }
    mysqli_query($conn, $sql);
    header("Location: $location");
}
function cust_edit($id) {
    global $conn;
    $sql = "SELECT * FROM customers WHERE id = '$id'";
    $data = mysqli_query($conn,$sql);
    $cust = mysqli_fetch_assoc($data);
    return $cust;
}
function cust_update($id, $name, $phone, $email, $address, $city, $bdate, $pcm) {
    global $conn;
    $sql = "UPDATE customers SET name = '$name',phone = '$phone',email = '$email',address = '$address',city_id = '$city',bdate = '$bdate',pcm = '$pcm' WHERE id = '$id'";
    mysqli_query($conn, $sql);
    header("Location: customers-list.php");
}
?>
