<?php 
function session() {
    if(!isset($_SESSION["username"])){
        header("Location: sign-in.php");
    } 
}  
?>