<?php
function check_user($username){
  global $conn;
  $sql = "SELECT count(id) AS users FROM employees WHERE username = '$username'";
  $data = mysqli_query($conn, $sql);
  $rec = mysqli_fetch_assoc($data);
  return $rec["users"];
  echo "ok";
}

function create_user($employee, $username, $password){
  global $conn;
  $pass = password_hash($password, PASSWORD_BCRYPT);
  $sql = "UPDATE employees SET username = '$username', password = '$pass' WHERE id = '$employee'";
  mysqli_query($conn, $sql);
  header('Location: sign-in.php');
}

function get_user($username){
  global $conn;
  $sql = "SELECT * FROM employees WHERE username = '$username'";
  $data = mysqli_query($conn, $sql);
  $user = mysqli_fetch_assoc($data);
  return $user;
}
?>
