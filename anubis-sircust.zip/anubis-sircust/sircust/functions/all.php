<?php
include "cities-functions.php";
include "contact-methods-functions.php";
include "customers-functions.php";
include "departments-functions.php";
include "products-functions.php";
include "request-types-functions.php";
include "stages-functions.php";
include "statuses-functions.php";
include "employees-functions.php";
include "auth-functions.php";
include "session-functions.php";
?>
