<?php
include "basic.php";
session();
if (isset($_POST["id"])) {
  cust_update($_POST["id"], $_POST["name"], $_POST["phone"], $_POST["email"], $_POST["address"], $_POST["city"], $_POST["bdate"], $_POST["pcm"]);
}

$cust = cust_edit($_GET["id"]);

$sql = "SELECT * FROM cities";
$cities_list = mysqli_query($conn, $sql);

$sql = "SELECT * FROM contact_methods";
$cm_list = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Edit Customer</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/bootstrap.bundle.min.js" charset="utf-8"></script>
    <script src="js/script.js" charset="utf-8"></script>
  </head>
  <body>
    <?php include "navbar.php"; ?>
    <h1>Edit Customer</h1>
    <form action="customers-edit.php" method="post">
      <label for="id">NameID</label>
      <input type="text" name="id"  value="<?php echo $cust["id"]; ?> " ></br>

      <label for="name">Name</label>
      <input type="text" name="name" value="<?php echo $cust["name"]; ?>"></br>

      <label for="phone">Phone</label>
      <input type="text" name="phone" value="<?php echo $cust["phone"]; ?>"></br>

      <label for="email">Email</label>
      <input type="text" name="email" value="<?php echo $cust["email"]; ?>" ></br>

      <label for="address">Address</label>
      <input type="text" name="address" value="<?php echo $cust["address"]; ?>" ></br>

      <label for="city">City</label>
      <select class="" name="city">
        <?php while($city = mysqli_fetch_assoc($cities_list)) { ?>
        <option <?php if($city["id"] == $cust["city_id"]) { echo "SELECTED"; } ?> value="<?php echo $city["id"]; ?>"><?php echo $city["name"]; ?></option>
        <?php } ?>
      </select><br>

      <label for="bdate">Birth Date</label>
      <input type="date" name="bdate" value="<?php echo $cust["bdate"]; ?>" ></br>

      <label for="pcm">Preferred Contact Method</label>
      <select class="" name="pcm">
        <?php while($cm = mysqli_fetch_assoc($cm_list)) { ?>
        <option <?php if($cm["id"] == $cust["pcm"]) { echo "SELECTED"; } ?> value="<?php echo $cm["id"]; ?>"><?php echo $cm["name"]; ?></option>
        <?php } ?>
      </select></br>

      <button type="submit">Save</button>
      <a href="#">Back</a>
    </form>
  </body>
</html>
