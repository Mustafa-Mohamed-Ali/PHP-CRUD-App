<?php
session_start();
$conn = mysqli_connect('localhost', 'root', '', 'sircust');
$companyName = "SirCust";
$logo = "company-logo.png";
include "functions/all.php"
?>
