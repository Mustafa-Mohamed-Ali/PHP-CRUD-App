<?php
include "basic.php";
session();
if(isset($_GET["depId"])) {
  dep_update($_POST["depId"], $_POST["depName"]);
}
$dep = dep_edit($_GET["id"]);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Edit Departments</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/bootstrap.bundle.min.js" charset="utf-8"></script>
    <script src="js/script.js" charset="utf-8"></script>
  </head>
  <body>
    <?php include "navbar.php"; ?>
    <h1>Edit Departments</h1>
    <form action="departments-update.php" method="post">
      <label for="depId">Department ID</lab  el>
      <input type="text" name="depId" value="<?php echo $dep["id"]; ?>">

      <label for="depName">Department Name</label>
      <input type="text" name="depName" value="<?php echo $dep["name"]; ?>">

      <button type="submit">Save</button>
      <a href="#">Back</a>
    </form>
  </body>
</html>
