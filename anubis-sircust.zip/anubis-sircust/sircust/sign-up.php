<?php
include 'basic.php';
if(isset($_POST["username"])){
  $nou = check_user($_POST["username"]);
  if($nou == 1){
    echo "This Username is already used";
  } else {
    create_user($_POST["employee"], $_POST["username"], $_POST["password"]);
  }
}
$employees = emp_list();
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Create a New Account - <?php echo $companyName; ?></title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/bootstrap.bundle.min.js" charset="utf-8"></script>
    <script src="js/script.js" charset="utf-8"></script>
  </head>
  <body>
    <div class="container">
      <h1 class="display-1 text-primary mt-5 mb-5">Create an Account</h1>
      <div class="row">
        <form action="sign-up.php" method="post">
          <div class="form-group">
            <label for="employee">Employee Name:</label>
            <select name="employee" class="form-control">
              <?php while($employee = mysqli_fetch_assoc($employees)){ ?>
              <option value="<?php echo $employee["empid"]; ?>"><?php echo $employee["empname"]; ?></option>
              <?php } ?>
            </select>
          </div>
          <div class="form-group">
            <label for="username">Username:</label>
            <input type="text" name="username" class="form-control">
          </div>
          <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" name="password" class="form-control">
          </div>
          <button type="submit" class="btn btn-primary mt-5">Create Account</button>
        </form>
        <p class="text-center mt-5">Have an Account ? Try to <a href="sign-in.php">Sign in</a></p>
      </div>
    </div>
  </body>
</html>
