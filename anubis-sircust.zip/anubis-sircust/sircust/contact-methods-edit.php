<?php
include "basic.php";
session();
if (isset($_POST["pcmId"])) {
  cm_update($_POST["pcmId"], $_POST["pcmName"]);
}
$pcm = cm_edit($_GET["id"]);
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Edit Contact-methods</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/bootstrap.bundle.min.js" charset="utf-8"></script>
    <script src="js/script.js" charset="utf-8"></script>
  </head>
  <body>
    <?php include "navbar.php"; ?>
    <h1>Edit Contact-methods</h1>
    <form action="contact-methods-edit.php" method="post">
      <label for="pcmId">Contact-method ID</label>
      <input type="text" name="pcmId" value="<?php echo $pcm["id"]; ?>">

      <label for="pcmName">Contact-method Name</label>
      <input type="text" name="pcmName" value="<?php echo $pcm["name"]; ?>">

      <button type="submit">Save</button>
      <a href="#">Back</a>
    </form>
  </body>
</html>
