<?php
include "basic.php";
session();
if(isset($_POST["reqName"])) {
  req_new($_POST["reqName"]);
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>New Request-type</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/bootstrap.bundle.min.js" charset="utf-8"></script>
    <script src="js/script.js" charset="utf-8"></script>
  </head>
  <body>
    <?php include "navbar.php"; ?>
    <h1>New Request-type</h1>
    <form action="Request-types-new.php" method="post">
      <label for="reqName">Request-type Name</label>
      <input type="text" name="reqName">

      <button type="submit">Save</button>
      <a href="#">Back</a>
    </form>
  </body>
</html>
