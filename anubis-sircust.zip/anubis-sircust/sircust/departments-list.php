<?php
include "basic.php";
session();
$data = dep_list();
if(isset($_GET["id"])) {
  dep_delete($id = $_GET["id"], $_GET["action"]);
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Departments List</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/bootstrap.bundle.min.js" charset="utf-8"></script>
    <script src="js/script.js" charset="utf-8"></script>
  </head>
  <body>
    <?php include 'navbar.php'; ?>
    <div class="container">
      <div class = "row">
        <h1 class="display-1 mt-4 mb-4">Departments List</h1>
        <table class="table table-bordered">
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Action</th>
          </tr>
          <?php while($dep = mysqli_fetch_assoc($data)){ ?>
            <tr>
              <td><?php echo $dep['id']; ?></td>
              <td><?php echo $dep['name']; ?></td>
              <td>
                <a class="btn btn-info" href="departments-edit.php?id=<?php echo $dep["id"]; ?>">Edit</a>
                <a class="btn btn-warning" href="departments-list.php?id=<?php echo $dep["id"]; ?>&action=delete">Delete</a>
              </td>
            </tr>
          <?php } ?>
        </table>
  </body>
</html>
