<?php
include "basic.php";
session();
if(isset($_POST['reqId'])) {
  req_update($_POST['reqId'], $_POST['reqName']);
}
$req = req_edit($_GET["id"]);
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Edit Request-types</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/bootstrap.bundle.min.js" charset="utf-8"></script>
    <script src="js/script.js" charset="utf-8"></script>
  </head>
  <body>
    <?php include "navbar.php"; ?>
    <h1>Edit Request-types</h1>
    <form action="request-types-edit.php" method="post">
      <label for="reqId">Request-type ID</label>
      <input type="text" name="reqId" value="<?php echo $req['id'] ;?>">
      <label for="reqName">Request-type Name</label>
      <input type="text" name="reqName" value="<?php echo $req['name'] ;?>">

      <button type="submit">Save</button>
      <a href="#">Back</a>
    </form>
  </body>
</html>
