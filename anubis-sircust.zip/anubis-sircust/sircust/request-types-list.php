<?php
include "basic.php";
session();
if(isset($_GET["id"])) {
  req_delete($_GET["id"], $_GET["action"]);
}
$data = req_list();
?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Request-types</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/bootstrap.bundle.min.js" charset="utf-8"></script>
    <script src="js/script.js" charset="utf-8"></script>
  </head>
  <body>
    <?php include "navbar.php"; ?>
    <div class="container">
      <div class = "row">
        <h1 class="display-1 mt-4 mb-4">Request-types List</h1>
        <table class="table table-bordered">
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Action</th>
          </tr>
          <?php while($req = mysqli_fetch_assoc($data)) { ?>
            <tr>
              <th><?php echo $req['id']; ?></th>
              <th><?php echo $req['name']; ?></th>
              <th>
                <a class="btn btn-info" href="request-types-edit.php?id=<?php echo $req['id'] ;?>">Edit</a>
                <a class="btn btn-warning" href="request-types-list.php?id=<?php echo $req['id'] ;?>&action=delete">Delete</a>
              </th>
            </tr>
          <?php } ?>
        </table>
  </body>
</html>
