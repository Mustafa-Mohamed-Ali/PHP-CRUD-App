<?php
include "basic.php";
session();
if(isset($_POST['stageId'])) {
  sta_update($_POST['stageId'], $_POST['stageName']);
}
$sta = sta_edit($_GET["id"]);
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Edit Stages</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/bootstrap.bundle.min.js" charset="utf-8"></script>
    <script src="js/script.js" charset="utf-8"></script>
  </head>
  <body>
    <?php include "navbar.php"; ?>
    <h1>Edit Stages</h1>
    <form action="stages-edit.php" method="post">
      <label for="stageId">Stage ID</label>
      <input type="text" name="stageId" value="<?php echo $sta['id'] ;?>">
      <label for="stageName">Stage Name</label>
      <input type="text" name="stageName" value="<?php echo $sta['name'] ;?>">

      <button type="submit">Save</button>
      <a href="#">Back</a>
    </form>
  </body>
</html>
