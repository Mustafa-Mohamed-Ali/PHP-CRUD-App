<?php
include "basic.php";
session();
if (isset($_GET["id"])) {
    emp_delete($_GET["id"], $_GET["action"]);
}
$data = emp_list("deleted");
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8">
    <title>Employees Trash</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/bootstrap.bundle.min.js" charset="utf-8"></script>
    <script src="js/script.js" charset="utf-8"></script>
</head>

<body>
    <?php include 'navbar.php'; ?>
    <div class="container">
        <div class="row">
            <h1 class="display-1 mt-4 mb-4 text-danger">Employees Trash</h1>
            <table class="table table-bordered">
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th>Job Title</th>
                    <th>Department ID</th>
                    <th>City ID</th>
                    <th>Action</th>
                </tr>
                <?php while ($emp = mysqli_fetch_assoc($data)) {  ?>
                <tr>
                    <td> <?php echo $emp["empid"]; ?> </td>
                    <td> <?php echo $emp["empname"]; ?> </td>
                    <td> <?php echo $emp["phone"]; ?> </td>
                    <td> <?php echo $emp["email"]; ?> </td>
                    <td> <?php echo $emp["job_title"]; ?> </td>
                    <td> <?php echo $emp["depname"]; ?> </td>
                    <td> <?php echo $emp["cityname"]; ?> </td>
                    <td>
                    <a class="btn btn-success" href="emp-trash.php?id=<?php echo $emp["empid"]; ?>&action=restore">Restore</a>
                    <a class="btn btn-danger" href="emp-trash.php?id=<?php echo $emp["empid"]; ?>&action=forever">Delete Forever</a>
                    </td>
                </tr>
                <?php } ?>
            </table>
        </div>
    </div>
</body>

</html>