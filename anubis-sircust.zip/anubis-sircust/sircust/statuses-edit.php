<?php
include "basic.php";
session();
if(isset($_POST['statId'])) {
  stat_update($_POST['statId'], $_POST['statName']);
}
$stat = stat_edit($_GET["id"]);
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Edit Status</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/bootstrap.bundle.min.js" charset="utf-8"></script>
    <script src="js/script.js" charset="utf-8"></script>
  </head>
  <body>
    <?php include "navbar.php"; ?>
    <h1>Edit Status</h1>
    <form action="statuses-edit.php" method="post">
      <label for="statId">Status ID</label>
      <input type="text" name="statId" value="<?php echo $stat['id'] ;?>">
      <label for="statName">Status Name</label>
      <input type="text" name="statName" value="<?php echo $stat['name'] ;?>">

      <button type="submit">Save</button>
      <a href="#">Back</a>
    </form>
  </body>
</html>
