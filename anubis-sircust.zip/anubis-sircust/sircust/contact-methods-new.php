<?php
include "basic.php";
session();
if (isset($_POST["cm"])) {
  cm_new($_POST["cm"]);
}

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>New Contact-method</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/bootstrap.bundle.min.js" charset="utf-8"></script>
    <script src="js/script.js" charset="utf-8"></script>
  </head>
  <body>
    <?php include 'navbar.php'; ?>
    <div class="container">
      <h1 class="display-1 mt-4 mb-4">New Contact-method</h1>
      <div class="row">
        <form action="Contact-methods-new.php" method="post">
          <div class="form-group mb-4">
            <label for="cm">Contact-method Name: </label>
            <input type="text" id="cm" name="cm" class="form-control">
          </div>
          <button type="submit" class="btn btn-success">Save</button>
          <a href="customers-list.php" class="btn btn-secondary">Back</a>
        </form>
      </div>
    </div>
  </body>
</html>
