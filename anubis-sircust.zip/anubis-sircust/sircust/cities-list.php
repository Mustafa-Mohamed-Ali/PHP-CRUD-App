<?php
include "basic.php";
session();
if (isset($_GET["id"])) {
  cities_delete($_GET["id"], $_GET["action"]);
}
$data = cities_list();
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Cities List</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/bootstrap.bundle.min.js" charset="utf-8"></script>
    <script src="js/script.js" charset="utf-8"></script>
  </head>
  <body>
    <?php include 'navbar.php'; ?>
    <div class="container">
      <div class="row">
        <h1 class="display-1">Cities List</h1>
        <table class="table">
          <tr>
            <th>#</th>
            <th>Name</th>
            <th>Action</th>
          </tr>
          <?php while($city = mysqli_fetch_assoc($data)) { ?>
          <tr>
            <td><img class="profile-img" src="img/cities/<?php echo $city["image"]; ?>"></td>
            <td><?php echo $city["name"]; ?></td>
            <td>
              <a class="btn btn-primary" href="cities-edit.php?id=<?php echo $city["id"]; ?>">Edit</a>
              <a class="btn btn-danger" href="cities-list.php?id=<?php echo $city["id"]; ?>&action=delete">Delete</a>
            </td>
          </tr>
          <?php } ?>
        </table>
      </div>
    </div>
  </body>
</html>
