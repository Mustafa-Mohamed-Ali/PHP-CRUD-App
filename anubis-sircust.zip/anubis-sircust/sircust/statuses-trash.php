<?php
include "basic.php";
session();
if(isset($_GET["id"])) {
  stat_delete($_GET["id"], $_GET["action"]);
}
$data = stat_list("deleted");
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Statuses</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/bootstrap.bundle.min.js" charset="utf-8"></script>
    <script src="js/script.js" charset="utf-8"></script>
  </head>
  <body>
    <?php include "navbar.php"; ?>
    <div class="container">
      <div class = "row">
        <h1 class="display-1 mt-4 mb-4 text-danger">Statuses List</h1>
        <table class="table table-bordered">
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Action</th>
          </tr>
          <?php while($stat = mysqli_fetch_assoc($data)) { ?>
            <tr>
              <th><?php echo $stat['id']; ?></th>
              <th><?php echo $stat['name']; ?></th>
              <th>
                <a class="btn btn-danger" href="statuses-trash.php?id=<?php echo $stat['id'] ;?>&action=restore">Restore</a>
                <a class="btn btn-success" href="statuses-trash.php?id=<?php echo $stat['id'] ;?>&action=forever">Delete Forever</a>
              </th>
            </tr>
          <?php } ?>
        </table>
  </body>
</html>
