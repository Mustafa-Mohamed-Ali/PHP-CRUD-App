<?php
include "basic.php";
session();
if(isset($_POST["name"])) {
  emp_new($_POST["name"], $_POST["phone"], $_POST["email"], $_POST["job_title"], $_POST["department_id"], $_POST["city_id"]);
}
$sql = " SELECT * FROM cities";
$cities_list = mysqli_query($conn, $sql);

$sql= "SELECT * FROM departments";
$dep_list = mysqli_query($conn,$sql);

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>New Employee</title>
    <link rel="stylesheet" href="css/styles.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">

        <script src="js/script.js" charset="utf-8"></script>
        <script src="js/bootstrap.bundle.min.js" charset="utf-8"></script>
  </head>
  <body>
    <?php include 'navbar.php'; ?>

    <h1 class="display-1">New Employee</h1>
    <form action="emp-new.php" method="post">
      <label >Employee Name</label>
      <input type="text" name="name"><br>

      <label >Phone Number</label>
      <input type="text" name="phone"><br>

      <label >Email</label>
      <input type="text" name="email"><br>

      <label >Job Title</label>
      <input type="text" name="job_title"><br>

      <label >Department</label>
      <select name="department_id" >
            <?php while($dep = mysqli_fetch_assoc($dep_list)){ ?>
            <option value="<?php echo $dep['id']; ?>"> <?php echo $dep['name']; ?></option>
            <?php } ?>
      </select><br>

      <label >City</label>
      <select name="city_id" >
            <?php while($city = mysqli_fetch_assoc($cities_list)){ ?>
            <option value="<?php echo $city['id']; ?>"> <?php echo $city['name']; ?></option>
            <?php } ?>

        </select><br>

      <button class="btn btn-warning" type="submit">Save</button>
      <a href="#">Back</a>
    </form>
  </body>
</html>
