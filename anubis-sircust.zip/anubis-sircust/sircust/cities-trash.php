<?php
include "basic.php";
session();
if (isset($_GET["id"])) {
  cities_delete($_GET["id"], $_GET["action"]);
}
$data = cities_list("deleted");
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Cities Trash</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/bootstrap.bundle.min.js" charset="utf-8"></script>
    <script src="js/script.js" charset="utf-8"></script>
  </head>
  <body>
    <?php include 'navbar.php'; ?>
    <div class="container">
      <div class="row">
        <h1 class="display-1 text-danger">Cities Trash</h1>
        <table class="table">
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Action</th>
          </tr>
          <?php while($city = mysqli_fetch_assoc($data)) { ?>
          <tr>
            <td><?php echo $city["id"]; ?></td>
            <td><?php echo $city["name"]; ?></td>
            <td>
              <a class="btn btn-success" href="cities-trash.php?id=<?php echo $city["id"]; ?>&action=restore">Restore</a>
              <a class="btn btn-danger" href="cities-trash.php?id=<?php echo $city["id"]; ?>&action=forever">Delete Forever</a>
            </td>
          </tr>
          <?php } ?>
        </table>
      </div>
    </div>
  </body>
</html>
