<?php
include "basic.php";
session();
if (isset($_GET["id"])) {
    cust_delete($_GET["id"], $_GET["action"]);
}
$data = cust_list("deleted");
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8">
    <title>Customers Trash</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/bootstrap.bundle.min.js" charset="utf-8"></script>
    <script src="js/script.js" charset="utf-8"></script>
</head>
<body>
    <?php include 'navbar.php'; ?>
    <div class="container">
        <div class="row">
            <h1 class="display-1 text-danger">Customers Trash</h1>
            <table class="table">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Phone</th>
                <th>Email</th>
                <th>Address</th>
                <th>City</th>
                <th>Birth Date</th>
                <th>Preferred Contact Method</th>
                <th>Action</th>
            </tr>
            <?php while($cust = mysqli_fetch_assoc($data)) { ?>
            <tr>
                    <td> <?php echo $cust["id"]; ?> </td>
                    <td> <?php echo $cust["cname"]; ?> </td>
                    <td> <?php echo $cust["phone"]; ?> </td>
                    <td> <?php echo $cust["email"]; ?> </td>
                    <td> <?php echo $cust["address"]; ?> </td>
                    <td> <?php echo $cust["cityname"]; ?> </td>
                    <td> <?php echo $cust["bdate"]; ?> </td>
                    <td> <?php echo $cust["cmname"]; ?> </td>
                    <td>
                        <a class="btn btn-success" href="customers-trash.php?id=<?php echo $cust["id"]; ?>&action=restore">Restore</a>
                        <a class="btn btn-danger" href="customers-trash.php?id=<?php echo $cust["id"]; ?>&action=forever">Delete Forever</a>
                    </td>
            </tr>
            <?php } ?>
            </table>
        </div>
    </div>
</body>
</html>
