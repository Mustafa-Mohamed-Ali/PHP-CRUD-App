<nav class="navbar navbar-expand-lg bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"><img id = "logo" src = "img/<?php echo $logo; ?>"></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Customers
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="customers-list.php">Customers List</a></li>
            <li><a class="dropdown-item" href="customers-new.php">New Customer</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="customers-trash.php">Customers Trash</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Cities
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="cities-list.php">Cities List</a></li>
            <li><a class="dropdown-item" href="cities-new.php">New City</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="cities-trash.php">Cities Trash</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Contact-methods
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="contact-methods-list.php">Contact-methods List</a></li>
            <li><a class="dropdown-item" href="contact-methods-new.php">Contact-methods New</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="contact-methods-trash">Contact-methods Trash</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Departments
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="departments-list.php">Departments List</a></li>
            <li><a class="dropdown-item" href="departments-new.php">Departments New</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="departments-trash.php">Departments Trash</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Products
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="products-list.php">Products List</a></li>
            <li><a class="dropdown-item" href="products-new.php">Products New</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="products-trash">Products Trash</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Request-types
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="request-types-list.php">Request-types List</a></li>
            <li><a class="dropdown-item" href="request-types-new.php">Request-types New</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="request-types-trash">Request-types Trash</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Stages
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="stages-list.php"> Stages List</a></li>
            <li><a class="dropdown-item" href="stages-new.php"> Stages New</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="stages-trash">Stages Trash</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Statuses
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="statuses-list.php"> Statuses List</a></li>
            <li><a class="dropdown-item" href="statuses-new.php"> Statuses New</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="statuses-trash">Statuses Trash</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Employees
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="emp-list.php">Employees List</a></li>
            <li><a class="dropdown-item" href="emp-new.php"> Employees New</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="emp-trash.php">Employees Trash</a></li>
          </ul>
        </li>
        <li class="nav-item">
        <a class="nav-link" href="end-session.php">Sign Out</a>
        </li>

      </ul>

    </div>
  </div>
</nav>
