<?php
include "basic.php";
session();
if(isset($_POST["stageName"])) {
  sta_new($_POST["stageName"]);
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>New Stages</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/bootstrap.bundle.min.js" charset="utf-8"></script>
    <script src="js/script.js" charset="utf-8"></script>
  </head>
  <body>
    <?php include "navbar.php"; ?>
    <h1>New Stage</h1>
    <form action="stages-new.php" method="post">
      <label for="stageName">Stage Name</label>
      <input type="text" name="stageName">

      <button type="submit">Save</button>
      <a href="#">Back</a>
    </form>
  </body>
</html>
