<?php
include "basic.php";
session();
if (isset($_GET["id"])) {
  cm_delete($_GET["id"], $_GET["action"]);
}
$data = cm_list("deleted");
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Contact-methods Trash</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/bootstrap.bundle.min.js" charset="utf-8"></script>
    <script src="js/script.js" charset="utf-8"></script>
  </head>
  <body>
    <?php include 'navbar.php'; ?>
    <div class="container">
      <div class="row">
        <h1 class="display-1 text-danger">Contact-methods Trash</h1>
        <table class="table">
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Action</th>
          </tr>
          <?php while($pcm = mysqli_fetch_assoc($data)) { ?>
          <tr>
            <td><?php echo $pcm["id"]; ?></td>
            <td><?php echo $pcm["name"]; ?></td>
            <td>
              <a class="btn btn-success" href="contact-methods-trash.php?id=<?php echo $pcm["id"]; ?>&action=restore">Restore</a>
              <a class="btn btn-danger" href="contact-methods-trash.php?id=<?php echo $pcm["id"]; ?>&action=forever">Delete Forever</a>
            </td>
          </tr>
          <?php } ?>
        </table>
      </div>
    </div>
  </body>
</html>
