<?php
include "basic.php";
session();
if(isset($_POST["statName"])) {
  stat_new($_POST["statName"]);
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>New Status</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/bootstrap.bundle.min.js" charset="utf-8"></script>
    <script src="js/script.js" charset="utf-8"></script>
  </head>
  <body>
    <?php include "navbar.php"; ?>
    <h1>New Status</h1>
    <form action="statuses-new.php" method="post">
      <label for="statuses">Status Name</label>
      <input type="text" name="statName">

      <button type="submit">Save</button>
      <a href="#">Back</a>
    </form>
  </body>
</html>
