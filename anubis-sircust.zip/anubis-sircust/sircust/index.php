<?php include 'basic.php';
if(!isset($_SESSION["username"])){
  header("Location: sign-in.php");
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title><?php echo $companyName; ?></title>
    <?php include 'head-assets.php'; ?>
  </head>
  <body>
    <?php include 'navbar.php'; ?>
    <div class="container">
      <div class="row mt-5">
        <a class="dashboard-box col-3 bg-success" href="customers-list.php">Customers</a>
        <a class="dashboard-box col-3 bg-success" href="cities-list.php">Cities</a>
        <a class="dashboard-box col-3 bg-success" href="employees-list.php">Employees</a>
        <a class="dashboard-box col-3 bg-success" href="departments-list.php">Departments</a>
      </div>
    </div>
  </body>
</html>
